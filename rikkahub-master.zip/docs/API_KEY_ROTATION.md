# API Key 顺序轮询功能说明

## 概述

RikkaHub 实现了类似 cherry-studio 的 API Key 顺序轮询机制，支持为每个 AI 提供商配置多个 API Key，系统会按顺序轮询使用这些 Key，有效避免单个 Key 的配额限制和频率限制。

## 支持的提供商

- ✅ **OpenAI Provider** - 完全支持
- ✅ **Google Provider** - 完全支持  
- ✅ **Claude Provider** - 完全支持

## 配置方法

### 1. 多 Key 配置格式

在提供商设置中，使用逗号分隔多个 API Key：

```
key1,key2,key3
```

**示例：**
```
sk-1234567890abcdef,sk-abcdef1234567890,sk-fedcba0987654321
```

### 2. 轮询机制

- **顺序轮询**：系统会按照配置的顺序依次使用每个 Key
- **状态持久化**：轮询状态保存在 SharedPreferences 中，应用重启后继续
- **提供商隔离**：不同提供商的轮询状态独立管理
- **自动回环**：使用完最后一个 Key 后自动回到第一个

### 3. 存储机制

轮询状态存储在：
- **文件名**：`api_key_rotator`
- **Key 格式**：`last_key_index_{providerId}`
- **存储位置**：应用私有 SharedPreferences

## 实现细节

### ApiKeyRotator 工具类

```kotlin
object ApiKeyRotator {
    fun getNextApiKey(context: Context, providerId: String, apiKeyString: String): String
}
```

### 各提供商集成

#### OpenAI Provider
```kotlin
private fun getNextApiKey(context: Context, providerSetting: ProviderSetting.OpenAI): String {
    return ApiKeyRotator.getNextApiKey(
        context,
        "openai_${providerSetting.id}",
        providerSetting.apiKey
    )
}
```

#### Google Provider
```kotlin
private fun getNextApiKey(context: Context, providerSetting: ProviderSetting.Google): String {
    return ApiKeyRotator.getNextApiKey(
        context,
        "google_${providerSetting.id}",
        providerSetting.apiKey
    )
}
```

#### Claude Provider
```kotlin
private fun getNextApiKey(context: Context, providerSetting: ProviderSetting.Claude): String {
    return ApiKeyRotator.getNextApiKey(
        context,
        "claude_${providerSetting.id}",
        providerSetting.apiKey
    )
}
```

## 使用建议

### 1. Key 配置最佳实践

- **数量建议**：建议配置 2-5 个 Key
- **配额分配**：确保每个 Key 都有足够的配额
- **有效性检查**：定期检查 Key 的有效性
- **权限一致**：确保所有 Key 具有相同的 API 权限

### 2. 故障处理

- **无效 Key**：系统会自动跳过无效的 Key
- **配额耗尽**：轮询到下一个 Key 继续服务
- **网络错误**：遵循正常的重试机制

### 3. 监控建议

- 监控各个 Key 的使用情况
- 定期检查轮询状态的均匀性
- 关注 API 调用的成功率

## 注意事项

1. **Key 格式**：确保所有 Key 格式正确且有效
2. **逗号分隔**：Key 之间必须用英文逗号分隔，不要有多余空格
3. **提供商限制**：某些提供商可能对同一账户的多 Key 使用有限制
4. **成本控制**：多 Key 可能增加 API 调用成本，请合理配置

## 故障排除

### 常见问题

**Q: 轮询不工作，总是使用同一个 Key？**
A: 检查 Key 配置格式，确保使用英文逗号分隔，没有多余空格。

**Q: 某个 Key 被跳过？**
A: 检查该 Key 是否有效，是否有足够配额。

**Q: 轮询状态丢失？**
A: 检查应用是否有 SharedPreferences 写入权限。

### 调试方法

1. 查看应用日志中的 API Key 使用情况
2. 检查 SharedPreferences 中的轮询状态
3. 验证每个 Key 的独立可用性