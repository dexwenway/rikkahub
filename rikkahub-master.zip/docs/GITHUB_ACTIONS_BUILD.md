# GitHub Actions 一键构建 APK 说明

## 概述

本项目配置了 GitHub Actions 工作流，支持一键构建 Debug APK，无需复杂的密钥配置，适合个人使用和测试。

## 工作流文件

### Debug Build (`debug-build.yml`)

**触发方式：** 手动触发 (workflow_dispatch)

**功能：**
- 构建 Debug APK
- 自动处理依赖和缓存
- 上传构建产物
- 无需签名密钥配置

## 使用方法

### 1. 手动触发构建

1. 进入 GitHub 仓库页面
2. 点击 **Actions** 标签
3. 选择 **Build Debug APK** 工作流
4. 点击 **Run workflow** 按钮
5. 确认触发构建

### 2. 下载 APK

构建完成后：
1. 在 Actions 页面找到对应的构建任务
2. 点击进入构建详情
3. 在 **Artifacts** 部分下载 `debug-apk-{run_number}`
4. 解压下载的文件获得 APK

## 构建环境配置

### Java 版本
- **JDK 17** (Temurin 发行版)
- 兼容项目的 Java 11 目标版本

### 依赖缓存
- Gradle 缓存：`~/.gradle/caches`
- Gradle Wrapper 缓存：`~/.gradle/wrapper`
- 缓存键基于 Gradle 文件哈希值

### Google Services 处理
- 自动创建 Debug 用的 `google-services.json`
- 使用模板文件避免 Firebase 配置错误
- 支持 Debug 包名：`me.rerere.rikkahub.debug`

## 构建产物

### APK 信息
- **文件名格式：** `rikkahub_{version}_{variant}.apk`
- **包名：** `me.rerere.rikkahub.debug`
- **签名：** Debug 签名（仅用于测试）
- **保留时间：** 30 天

### 上传配置
- **Artifact 名称：** `debug-apk-{构建编号}`
- **路径：** `app/build/outputs/apk/debug/*.apk`
- **错误处理：** 如果没有找到 APK 文件会报错

## 故障排除

### 常见问题

**Q: 构建失败，提示 Java 版本问题？**
A: 工作流使用 JDK 17，项目目标是 Java 11，这是正常的向下兼容配置。

**Q: 找不到 google-services.json？**
A: 工作流会自动创建模板文件，无需手动配置。

**Q: APK 上传失败？**
A: 检查构建日志中的 "List build outputs" 步骤，确认 APK 文件生成位置。

**Q: 下载的 APK 无法安装？**
A: Debug APK 使用测试签名，需要在设备上启用"未知来源"安装。

### 调试步骤

1. **查看构建日志**
   - 点击失败的构建任务
   - 展开各个步骤查看详细日志
   - 重点关注 "Build debug APK" 步骤

2. **检查依赖问题**
   - 查看 "Setup Gradle cache" 步骤
   - 确认依赖下载是否成功

3. **验证 APK 生成**
   - 查看 "List build outputs" 步骤
   - 确认 APK 文件路径和大小

## 高级配置

### 自定义构建参数

如需修改构建参数，编辑 `.github/workflows/debug-build.yml`：

```yaml
- name: Build debug APK
  run: ./gradlew assembleDebug --stacktrace --info
```

可用参数：
- `--stacktrace`: 显示详细错误堆栈
- `--info`: 显示详细构建信息
- `--debug`: 显示调试级别日志
- `--parallel`: 启用并行构建

### 缓存优化

当前缓存配置已优化，如需调整：

```yaml
- name: Setup Gradle cache
  uses: actions/cache@v4
  with:
    path: |
      ~/.gradle/caches
      ~/.gradle/wrapper
    key: ${{ runner.os }}-gradle-${{ hashFiles('**/*.gradle*', '**/gradle-wrapper.properties') }}
```

### 构建矩阵

如需支持多个 Android API 级别或架构，可配置构建矩阵：

```yaml
strategy:
  matrix:
    api-level: [26, 30, 34]
```

## 安全注意事项

1. **Debug 签名**：构建的 APK 使用 Debug 签名，仅用于测试
2. **无敏感信息**：工作流不包含任何 API 密钥或敏感配置
3. **公开仓库**：构建产物在公开仓库中可见
4. **权限控制**：只有仓库协作者可以触发构建

## 扩展功能

### Release 构建

如需 Release 构建，需要配置：
1. 签名密钥（Keystore）
2. GitHub Secrets 存储敏感信息
3. 修改 `release.yml` 工作流

### 自动触发

可配置自动触发条件：
```yaml
on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]
```

### 多平台支持

当前支持 Linux (ubuntu-latest)，可扩展支持：
- Windows: `windows-latest`
- macOS: `macos-latest`